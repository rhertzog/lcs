Please see http://wiki.phpldapadmin.info/Translating now for information on
translating PLA.
