<?php
# This is a temporary file
@define('LIBDIR',sprintf('%s/',realpath('../lib/')));
require LIBDIR.'common.php';
?>
