<?php

// ACCESSIBILITE
// la page /oo offre une lecture en mode "texte seul"

@header("Location: ../?set_disp=4&set_options=basiques&exec=" . $_REQUEST['exec']);

?>
