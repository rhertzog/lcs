<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de http://www.spip.net/trad-lang/
// ** ne pas modifier le fichier **

if (!defined("_ECRIRE_INC_VERSION")) return;

$GLOBALS[$GLOBALS['idx_lang']] = array(

// A
'accueil_site' => 'H&#596;ntogbo',
'articles' => 'Wekpa l&#603;&#770;',
'articles_auteur' => 'Ny&#596;wlant&#596; &eacute; l&#596; sin wekpa l&#603;&#770;',
'articles_populaires' => 'wekpa l&#603;&#770;  &ecirc; to bi t&ugrave;n y&eacute;',
'articles_rubrique' => 'wekpa &#598;i&#598;&#603; &eacute; l&#596; t&#596;n',
'aucun_article' => 'wekpa &#598;e&#772;&#772;  do gesi &eacute; l&#596; ji a ',
'aucun_auteur' => 'Ny&#596;wlant&#596; &#598;e&#772;&#772;  do  gesi &eacute; l&#596; ji a ',
'aucun_site' => 'Gblogbloji &#598;e&#772;&#772;  do  gesi &eacute; l&#596; ji a',
'aucune_breve' => 'Xogb&egrave; kl&eacute;wun &#598;e&#772;&#772;  do  gesi &eacute; l&#596; ji a',
'aucune_rubrique' => '&#598;i&#598;&#603; &#598;e&#772;&#772; do gesi &eacute; l&#596; ji a ',
'autres_breves' => 'Xogb&egrave; kl&eacute;wun de vo',
'autres_groupes_mots_clefs' => 'Xota b&#603; dokp&#596; l&#603;&#770; ',
'autres_sites' => 'Gblogbloji &#598;e&#772;&#772; vo l&#603;&#770;',

// B
'bonjour' => 'kwab&#596;   ',
'breves' => 'Xogb&egrave; kl&eacute;wun',

// C
'commenter_site' => 'wl&#596;k&agrave;nn&uacute; xo l&#603;&#770;',

// D
'date' => 'Azan',
'dernier_ajout' => 'G&#596;na g&ugrave;dog&ugrave;dot&#596;n',
'dernieres_breves' => 'Xogb&egrave; kl&eacute;wun g&ugrave;dog&ugrave;dot&#596;n',
'derniers_articles' => 'Wekpa g&ugrave;dog&ugrave;dot&#596;n',
'derniers_commentaires' => '&#598;&#603;tit&#603; g&ugrave;dog&ugrave;dot&#596;n',
'derniers_messages_forum' => 'wh&#603;n g&ugrave;dog&ugrave;dot&#596;n ye&#772; &#598;&#596;dotoji',

// E
'edition_mode_texte' => 'winwlanm&#603;',
'en_reponse' => '&#598;ogb&egrave;yiyi m&#603; nu &nbsp;:',
'en_resume' => '&#598;o xo kl&eacute;wun m&#603; &#596;',
'envoyer_message' => 'S&#603; w&#603;n do ',
'espace_prive' => 't&#603;nkandovo',

// F
'forum' => 'Kpl&eacute;kpl&eacute; ',

// H
'hierarchie_site' => 'Tito gblogbloji &#596; t&#596;n',

// J
'jours' => 'Azan l&#603;&#770;',

// M
'meme_auteur' => 'Ny&#596;wlant&#596; &#598;okpo &#596;',
'meme_rubrique' => '&#598;o akpaxw&eacute; &#598;okpo &#596; m&#603;',
'memes_auteurs' => 'Ny&#596;wlant&#596; &#598;okpo l&#603;&#770;',
'message' => 'W&#603;n',
'messages_forum' => 'w&#603;n pk&eacute;kpl&eacute; &#596; t&#596;n l&ecirc;',
'messages_recents' => 'w&#603;n g&ugrave;do&#769;g&ugrave;dot&#596;n pk&eacute;kpl&eacute; &#596; t&#596;n l&ecirc;',
'mots_clefs' => 'xo&#769;ta&#769; l&#603;&#770;',
'mots_clefs_meme_groupe' => 'xo&#769;ta&#769; akpa &#598;okpo&#769; &#596; l&#603;&#770; t&#596;n',

// N
'navigation' => 'nuk&eacute;j&eacute;k&eacute;j&eacute;',
'nom' => 'nyi&#769;k&#596;',
'nouveautes' => 'Nu y&#596;y&#596; l&#603;&#770;',
'nouveautes_web' => 'Nu y&#596;y&#596; l&#603;&#770;  e &#598;o at&#603; &#596; ji&#769; &#596;',
'nouveaux_articles' => 'W&eacute;kpa y&#596;y&#596; l&#603;&#770;',
'nouvelles_breves' => 'w&#603;n kl&eacute;wun l&#603;&#770;',

// P
'page_precedente' => 'W&eacute;kpa e wai',
'page_suivante' => 'W&eacute;kpa e b&#596;&#598;&eacute;u',
'par_auteur' => 'Gb&#596;n',
'participer_site' => 'Mi&#768; &#598;&egrave; mi&#768; &#598;&eacute; xl&#603; bo&#769; na&#769;  siwu k&#603; nu&#768; do&#769; wal&#596; gblogbloji&#769; &#596; t&#596;n  en&#603; gu&#769;do &#596; mi&#768;  singan    s&#596; w&eacute;kpa mi t&#596;n l&#603;&#770; s&#603;  do&#769;. &#598;o m&#596; &#596;, mi&#768; n&agrave; s&#603; gb&egrave;t&agrave;kwin na&#769; na&#769; gb&egrave; b&#596; mi&#768; &#598;o t&agrave;f&#596; at&#603; &#596; ji&#769;  z&#596;n&#598;okpo e.',
'plan_site' => 'titom&#603; gblogbloji &#596; t&#596;n ',
'popularite' => 'Nuku&#769;n &#598;&eacute;ji&#769;',
'poster_message' => 's&#603; w&#603;n do',
'proposer_site' => 'Nu mi do gblogbloji&#769; &#598;&eacute; &#596;  Mi&#768; siwu z&eacute; g&#596; na&#769; akpa &eacute; l&#596; ',

// R
'repondre_article' => '&#598;o&#768; sin nu w&eacute;kpa e l&#596;',
'repondre_breve' => '&#598;o&#768; sin nu xo&#769; klewun &eacute; l&#596;',
'repondre_message' => '&#598;o&#768; sin nu w&#603;n  &eacute; l&#596;',
'resultats_recherche' => 'Gb&egrave;tak&#603;n nu do biba t&#596;n l&#603;&#770;',
'retour_debut_forums' => 'k&#596;l&#603; s&#596; yi&#768;  kpl&eacute;kpl&eacute; sin bib&#603;',
'rubrique' => 'Akpa ',
'rubriques' => 'Akpa l&#603;',

// S
'signatures_petition' => 'al&#596;dowemam&#603; l&#603;',
'site_realise_avec_spip' => 'Kpo al&#596;g&#596; Supipu t&#596;n kpo&#769; w&#603; gblogbloji&#769; &#596; nyi&#769; wiwa',
'sites_web' => 'At&#603; l&#603;&#770;',
'sous_rubriques' => 'Akpa xw&eacute;',
'suite' => 'B&#596; &#598;&eacute; wu t&#596;n',
'sur_web' => '&#598;o&#768; at&#603; &#596;  ji&#768;',
'syndiquer_rubrique' => 'Ze&#770; aceji do akpa &eacute; l&#596; ji&#769;',
'syndiquer_site' => 'ac&eacute;ji&#769;ni&#769;n&#596;',

// T
'texte_lettre_information' => 'Xojlawema&#769; gblogbloji &#596; t&#596;n &#598;i&egrave;',
'texte_lettre_information_2' => 'Xojlawema&#769; &eacute; l&#596;&#596; n&#596; cian w&eacute;kpa kpodo&#769; xo&#769; klewun &#598;&#596;&#768;dotoji&#769; xoxo l&#603;&#770;',

// V
'ver_imprimer' => 'Zin wema',
'voir_en_ligne' => 'kp&#596;n Gblogbloji',
'voir_squelette' => 'S&#603; titom&#603; wema &eacute;l&#596; t&#596;n do '
);

?>
