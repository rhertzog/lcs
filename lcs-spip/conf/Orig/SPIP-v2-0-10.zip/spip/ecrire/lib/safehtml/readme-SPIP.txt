
SafeHTML pour SPIP

--------
Version 1.3.7.
http://pixel-apes.com/safehtml/
--------

Ce repertoire est extrait de SafeHTML 1.3.7 ; les fichiers suivants ont ete supprimes :

safehtml/safehtml.php
safehtml/tests/*

On s'appuie sur la version sans commentaires (un peu plus legere) 

