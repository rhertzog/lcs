<?php
// This is a SPIP language file  --  Esto es un archivo de idioma SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(

// Aide des boutons suppl�mentaires de la barre typo
'barre_intertitre2' => 'Transformar en {2{intert&iacute;tulos nivel dos}2}',
'barre_intertitre3' => 'Transformar en {3{intert&iacute;tulos nivel tres}3}',
'barre_miseenevidence' => 'Poner el texto en [*evidencia*]',
'barre_exposant' => 'Poner el texto en &lt;sup&gt;potencia&lt;/sup&gt;',
'barre_petitescapitales' => 'Poner el texto en &lt;sc&gt;may&uacute;sculas peque&ntilde;as&lt;/sc&gt;',
'barre_centrer' => '[|Centrar|] el p&aacute;rrafo',
'barre_alignerdroite' => '[/Al&iacute;nea a la derecha/] el p&aacute;rrafo',
'barre_encadrer' => '[(Encuadrar)] el p&aacute;rrafo',

'barre_poesie' => 'Mettre en forme comme une &lt;poesie&gt;po&eacute;sie&lt;/poesie&gt;',

'barre_avances' => 'Du sens, du sens&nbsp;!',
'barre_boutonsavances' => 'Mises en sens suppl&eacute;mentaires, &agrave; utiliser avec mod&eacute;ration et discernement&nbsp;!',

'cfg_puces' => 'Traitement des puces',
'cfg_titraille' => 'Titraille',
'cfg_insertcss' => 'Insertion CSS'

);
?>
