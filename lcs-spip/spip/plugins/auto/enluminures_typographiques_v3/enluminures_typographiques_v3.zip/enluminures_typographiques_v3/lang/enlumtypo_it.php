<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(

// Aide des boutons suppl�mentaires de la barre typo
'barre_intertitre2' => 'Converti in {2{sottotitolo 2o-livello}2}',
'barre_intertitre3' => 'Converti in {3{sottotitolo 3o-livello}3}',
'barre_miseenevidence' => '[*Evidenziare*] il testo',
'barre_exposant' => 'Sovrimpressione',
'barre_petitescapitales' => 'Maiuscoletto',
'barre_centrer' => '[|Centrare|] il paragrafo',
'barre_alignerdroite' => '[/allinea a destra/] il paragrafo',
'barre_encadrer' => '[(Riquadro)] attorno al paragrafo',

'barre_poesie' => 'stile poetico',

'barre_avances' => 'Allineamento&nbsp;!',
'barre_boutonsavances' => 'Formattazione supplementare, utilizzare con moderazione e discernimento&nbsp;!',

'cfg_puces' => 'Traitement des puces',
'cfg_titraille' => 'Titraille',
'cfg_insertcss' => 'Insertion CSS'

);
?>