<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP

$GLOBALS[$GLOBALS['idx_lang']] = array(

// Aide des boutons suppl�mentaires de la barre typo
'barre_intertitre2' => 'Turn into a {2{2nd-level subtitle}2}',
'barre_intertitre3' => 'Turn into a {3{3rd-level subtitle}3}',
'barre_miseenevidence' => '[*Accentuate*] the text',
'barre_exposant' => 'Superscript',
'barre_petitescapitales' => 'Small caps',
'barre_centrer' => '[|Centre|] the paragraph',
'barre_alignerdroite' => '[/Right-align/] the paragraph',
'barre_encadrer' => '[(Place a border)] round the paragraph',

'barre_poesie' => 'display like poetry',

'barre_avances' => 'Meaning, not apparence!',
'barre_boutonsavances' => 'Extra justifications, use with caution!',

'cfg_puces' => 'Bullets',
'cfg_titraille' => 'Headings',
'cfg_insertcss' => 'Inser CSS'

);
?>
